Module.register("MMM-HologramShowcase", {
  defaults: {
    items: [
      {
        title: "Sci-Fi Hologram A",
        image: "images/person1.jpg",
        audio: "audio/person1.ogg",
        model: "models/person1.glb"
      },
      {
        title: "Sci-Fi Hologram B",
        image: "images/person2.jpg",
        audio: "audio/person2.ogg",
        model: "models/person2.glb"
      },
      {
        title: "Sci-Fi Hologram C",
        image: "images/person3.jpg",
        audio: "audio/person3.ogg",
        model: "models/person3.glb"
      }
    ],
    sliderHeight: "260px",
    autoScroll: true,
    autoScrollDelay: 2500,
    autoScrollSpeed: 0.6,
    idleAutoPlay: false,
    idleSecondsToPlay: 10,
    showTitleOnHolo: true,
    hologramColor: 0x3ad0ff,
    thumbnailSize: 220
  },

  getStyles: function() {
    return ["MMM-HologramShowcase.css"];
  },

  getScripts: function() {
    return [
      "https://unpkg.com/three@0.158.0/build/three.min.js",
      "https://unpkg.com/three@0.158.0/examples/js/controls/OrbitControls.js",
      "https://unpkg.com/three@0.158.0/examples/js/loaders/GLTFLoader.js"
    ];
  },

  start: function() {
    Log.info("MMM-HologramShowcase starting...");
    this.currentIndex = 0;
    this._touch = {active:false, startX:0, scrollLeft:0, vx:0, lastT:0, lastX:0};
    this._autoScrollTimer = null;
    this._idleTimer = null;
    this._isPlaying = false;
  },

  getDom: function() {
    const wrapper = document.createElement("div");
    wrapper.className = "holo-slider-wrap";

    const slider = document.createElement("div");
    slider.className = "holo-slider";
    slider.style.height = this.config.sliderHeight;
    slider.id = "holo-slider";

    this.config.items.forEach((item, idx) => {
      const card = document.createElement("div");
      card.className = "holo-card";
      card.tabIndex = 0;

      const img = document.createElement("img");
      img.className = "holo-thumb";
      img.style.width = this.config.thumbnailSize + "px";
      img.style.height = (this.config.thumbnailSize) + "px";
      img.src = this.file(item.image);
      img.alt = item.title;
      card.appendChild(img);

      const caption = document.createElement("div");
      caption.className = "holo-caption";
      caption.innerText = item.title;
      card.appendChild(caption);

      card.addEventListener("click", () => {
        this.openHologram(item);
      });
      slider.appendChild(card);
    });

    // touch/drag kinetic scrolling
    slider.addEventListener('pointerdown', (e)=> this.onPointerDown(e));
    window.addEventListener('pointermove', (e)=> this.onPointerMove(e));
    window.addEventListener('pointerup', (e)=> this.onPointerUp(e));
    slider.addEventListener('wheel', (e)=> { e.preventDefault(); slider.scrollLeft += e.deltaY; });

    wrapper.appendChild(slider);

    // hologram overlay
    const overlay = document.createElement("div");
    overlay.id = "holo-popup";
    overlay.innerHTML = `
      <div id="holo-close" title="Close">✕</div>
      <div id="holo-title"></div>
      <div id="holo-container"></div>
      <div id="holo-bottom">
        <button id="holo-back">Back</button>
      </div>
    `;
    wrapper.appendChild(overlay);

    // audio element
    const audio = document.createElement("audio");
    audio.id = "holo-audio";
    audio.preload = "auto";
    audio.volume = 0.0;
    wrapper.appendChild(audio);

    // start auto scroll if enabled
    if (this.config.autoScroll) {
      this.startAutoScroll();
    }

    // idle autoplay
    if (this.config.idleAutoPlay) {
      this.resetIdleTimer();
      ['click','touchstart','mousemove','keydown'].forEach(evt => {
        window.addEventListener(evt, ()=> this.resetIdleTimer());
      });
    }

    return wrapper;
  },

  onPointerDown: function(e) {
    const slider = document.getElementById('holo-slider');
    this._touch.active = true;
    this._touch.startX = e.pageX;
    this._touch.scrollLeft = slider.scrollLeft;
    this._touch.vx = 0;
    this._touch.lastT = performance.now();
    this._touch.lastX = e.pageX;
  },

  onPointerMove: function(e) {
    if (!this._touch.active) return;
    const slider = document.getElementById('holo-slider');
    const dx = e.pageX - this._touch.startX;
    slider.scrollLeft = this._touch.scrollLeft - dx;
    const now = performance.now();
    const dt = now - this._touch.lastT;
    if (dt>0) {
      this._touch.vx = (e.pageX - this._touch.lastX)/dt;
      this._touch.lastT = now;
      this._touch.lastX = e.pageX;
    }
  },

  onPointerUp: function(e) {
    if (!this._touch.active) return;
    this._touch.active = false;
    const slider = document.getElementById('holo-slider');
    // momentum
    let vx = this._touch.vx * 40; // scale
    const step = ()=> {
      if (Math.abs(vx) < 0.02) return;
      slider.scrollLeft -= vx;
      vx *= 0.95;
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  },

  startAutoScroll: function() {
    const slider = document.getElementById('holo-slider');
    if (!slider) return;
    const step = ()=> {
      slider.scrollLeft += this.config.autoScrollSpeed;
      this._autoScrollTimer = setTimeout(step, this.config.autoScrollDelay);
    };
    this._autoScrollTimer = setTimeout(step, this.config.autoScrollDelay);
  },

  stopAutoScroll: function() {
    if (this._autoScrollTimer) { clearTimeout(this._autoScrollTimer); this._autoScrollTimer = null; }
  },

  resetIdleTimer: function() {
    if (this._idleTimer) clearTimeout(this._idleTimer);
    this._idleTimer = setTimeout(()=> {
      // auto-play first item
      const it = this.config.items[0];
      if (it) this.openHologram(it);
    }, this.config.idleSecondsToPlay*1000);
  },

  openHologram: function(item) {
    const overlay = document.getElementById("holo-popup");
    const titleEl = document.getElementById("holo-title");
    const audioEl = document.getElementById("holo-audio");

    titleEl.innerText = (this.config.showTitleOnHolo ? item.title : "");
    audioEl.src = this.file(item.audio);
    audioEl.currentTime = 0;
    audioEl.volume = 0.0;
    audioEl.play().catch(e=>{console.log("audio play failed:",e);});
    // fade-in audio
    this._isPlaying = true;
    let vol = 0.0;
    const fadeIn = ()=> {
      if (!this._isPlaying) return;
      vol += 0.02;
      audioEl.volume = Math.min(1.0, vol);
      if (vol < 0.98) requestAnimationFrame(fadeIn);
    };
    requestAnimationFrame(fadeIn);

    overlay.style.display = "flex";
    this.initThree(item);

    document.getElementById("holo-close").onclick = () => this.closeHologram();
    document.getElementById("holo-back").onclick = () => this.closeHologram();
    overlay.onclick = (ev) => { if (ev.target === overlay) this.closeHologram(); };
  },

  closeHologram: function() {
    const overlay = document.getElementById("holo-popup");
    overlay.style.display = "none";
    const audioEl = document.getElementById("holo-audio");
    // fade-out
    this._isPlaying = false;
    let vol = audioEl.volume;
    const fadeOut = ()=> {
      vol -= 0.06;
      if (vol <= 0) { try{ audioEl.pause(); audioEl.currentTime=0;}catch(e){}; return; }
      audioEl.volume = vol;
      requestAnimationFrame(fadeOut);
    };
    requestAnimationFrame(fadeOut);

    if (this.renderer) {
      try {
        cancelAnimationFrame(this._animFrame);
        this.renderer.dispose();
        this.scene = null;
        this.camera = null;
        this.renderer.domElement.remove();
        this.renderer = null;
      } catch(e){console.log("dispose err",e);}
    }
  },

  initThree: function(item) {
    const container = document.getElementById("holo-container");
    container.innerHTML = "";
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(window.devicePixelRatio || 1);
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const color = this.config.hologramColor || 0x3ad0ff;
    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
    this.camera.position.set(0, 0.6, 2.2);

    const amb = new THREE.AmbientLight(0x88cfe8, 0.6);
    this.scene.add(amb);
    const p = new THREE.PointLight(0x88e7ff, 1.2);
    p.position.set(5,5,5);
    this.scene.add(p);

    // If model file exists and size>0, load GLTF; else draw procedural hologram
    const modelUrl = this.file(item.model);
    fetch(modelUrl, { method: 'HEAD' }).then(resp => {
      if (resp.ok && parseInt(resp.headers.get('content-length') || '0')>100) {
        const loader = new THREE.GLTFLoader();
        loader.load(this.file(item.model), gltf => {
          this.scene.add(gltf.scene);
          this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
          this.controls.autoRotate = true;
          this.controls.autoRotateSpeed = 0.6;
          this.animateThree();
        }, undefined, err=> {
          console.log("gltf load err", err);
          this.buildProcedural(color);
          this.animateThree();
        });
      } else {
        this.buildProcedural(color);
        this.animateThree();
      }
    }).catch(err=>{
      console.log("head fetch err", err);
      this.buildProcedural(color);
      this.animateThree();
    });
  },

  buildProcedural: function(color) {
    const group = new THREE.Group();
    const geoSphere = new THREE.SphereGeometry(0.7, 32, 32);
    const matShell = new THREE.MeshPhongMaterial({
      color: color,
      emissive: color,
      transparent: true,
      opacity: 0.12,
      shininess: 100,
      side: THREE.DoubleSide
    });
    const shell = new THREE.Mesh(geoSphere, matShell);
    group.add(shell);

    const torusGeo = new THREE.TorusKnotGeometry(0.35, 0.09, 120, 16);
    const matCore = new THREE.MeshStandardMaterial({
      color: color,
      emissive: color,
      metalness: 0.1,
      roughness: 0.2,
      transparent: true,
      opacity: 0.9
    });
    const core = new THREE.Mesh(torusGeo, matCore);
    core.name = "core";
    group.add(core);

    for(let i=0;i<12;i++){
      const ring = new THREE.RingGeometry(0.25 + i*0.03, 0.28 + i*0.03, 64);
      const matRing = new THREE.MeshBasicMaterial({
        color: color,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.06
      });
      const r = new THREE.Mesh(ring, matRing);
      r.rotation.x = Math.PI/2;
      r.position.y = -0.3 + i*0.06;
      group.add(r);
    }

    this.scene.add(group);
    this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
    this.controls.autoRotate = true;
    this.controls.autoRotateSpeed = 0.6;
  },

  animateThree: function() {
    const core = this.scene.getObjectByName("core");
    const loop = ()=> {
      if (!this.renderer) return;
      if (core) { core.rotation.y += 0.01; core.rotation.x += 0.004; }
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
      this._animFrame = requestAnimationFrame(loop);
    };
    loop();
  }

});